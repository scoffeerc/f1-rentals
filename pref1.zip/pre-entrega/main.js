document.addEventListener("DOMContentLoaded", () => {
  // Menú móvil
  const menuToggle = document.querySelector(".menu-toggle")
  const navLinks = document.querySelector(".nav-links")

  if (menuToggle) {
    menuToggle.addEventListener("click", () => {
      navLinks.classList.toggle("active")
    })
  }

  // Datos de autos populares (simulado)
  function getPopularCars() {
    return [
      {
        id: "1",
        name: "McLaren MP4/4",
        team: "McLaren",
        year: 1988,
        price: 35000,
        image: "img/cars/mclaren/mclarenmp.webp",
        description:
          "The McLaren MCL35M was a Formula One car designed and constructed by McLaren for the 2021 Formula One World Championship.",
      },
      {
        id: "2",
        name: "Alpine A521",
        team: "Alpine F1 Team",
        year: 2021,
        price: 2000,
        image: "img/cars/alpine/alpine.jpg",
        description:
          "The Alpine A521 was a Formula One car designed and constructed by Alpine F1 Team for the 2021 Formula One World Championship.",
      },
      {
        id: "3",
        name: "Mercedes-AMG W11",
        team: "Mercedes-AMG Petronas",
        year: 2021,
        price: 5000,
        image: "img/cars/mercedes/mercedes.jpg",
        description:
          "The Mercedes-AMG Petronas W12 was a Formula One car designed and constructed by the Mercedes-AMG Petronas Formula One Team for the 2021 Formula One World Championship.",
      },
    ]
  }

  // Cargar autos populares en la página de inicio
  const popularCarsContainer = document.getElementById("popular-cars-container")

  if (popularCarsContainer) {
    const popularCars = getPopularCars()

    popularCars.forEach((car) => {
      const carCard = createCarCard(car)
      popularCarsContainer.appendChild(carCard)
    })
  }

  // Función para crear una tarjeta de auto
  function createCarCard(car) {
    const carCard = document.createElement("div")
    carCard.className = "car-card"

    carCard.innerHTML = `
            <div class="car-image">
                <img src="${car.image}" alt="${car.name}">
            </div>
            <div class="car-info">
                <h3>${car.name}</h3>
                <p class="team">${car.team}</p>
                <p class="year">${car.year}</p>
                <p class="price">€${car.price.toLocaleString()} / día</p>
                <a href="detail.html?id=${car.id}" class="btn btn-primary">Ver Detalles</a>
            </div>
        `

    return carCard
  }

  // Manejar envío de formularios
  const contactForm = document.querySelector(".contact-form form")

  if (contactForm) {
    contactForm.addEventListener("submit", (e) => {
      e.preventDefault()
      alert("Mensaje enviado con éxito. Nos pondremos en contacto contigo pronto.")
      contactForm.reset()
    })
  }

  const newsletterForm = document.querySelector(".footer-newsletter form")

  if (newsletterForm) {
    newsletterForm.addEventListener("submit", (e) => {
      e.preventDefault()
      alert("¡Gracias por suscribirte a nuestro newsletter!")
      newsletterForm.reset()
    })
  }
})

document.addEventListener('DOMContentLoaded', () => {
  // Código existente...
  
  // Manejo del video de fondo
  const heroVideo = document.getElementById('hero-video');
  
  // Verificar si el video existe en la página
  if (heroVideo) {
      // Función para verificar si el dispositivo es móvil
      function isMobileDevice() {
          return (window.innerWidth <= 768 || 
                 ('ontouchstart' in window) || 
                 (navigator.maxTouchPoints > 0) || 
                 (navigator.msMaxTouchPoints > 0));
      }
      
      // En dispositivos móviles, podemos pausar el video para ahorrar recursos
      if (isMobileDevice()) {
          // Opción 1: Pausar el video en móviles
          // heroVideo.pause();
          
          // Opción 2: Reducir la calidad/framerate para móviles
          heroVideo.setAttribute('playbackRate', '0.5');
      }
      
      // Asegurarse de que el video se reproduzca incluso si el autoplay falla
      heroVideo.addEventListener('canplay', () => {
          heroVideo.play().catch(e => {
              console.log('Autoplay prevented:', e);
              // Crear un botón para reproducir manualmente si el autoplay falla
              const playButton = document.createElement('button');
              playButton.innerHTML = '<i class="fas fa-play"></i> Reproducir Video';
              playButton.className = 'video-play-btn';
              document.querySelector('.hero-content').prepend(playButton);
              
              playButton.addEventListener('click', () => {
                  heroVideo.play();
                  playButton.style.display = 'none';
              });
          });
      });
  }
});

// Añade esto a tu main.js
document.addEventListener('DOMContentLoaded', () => {
  // Registrar el plugin ScrollTrigger
  gsap.registerPlugin(ScrollTrigger);
  
  // Animación para el título principal
  gsap.from(".hero h1", {
      duration: 1.5,
      opacity: 0,
      y: 50,
      stagger: 0.3,
      ease: "power4.out"
  });
  
  // Animación para las tarjetas de características
  gsap.from(".feature-card", {
      scrollTrigger: {
          trigger: ".features",
          start: "top 80%",
      },
      duration: 0.8,
      opacity: 0,
      y: 50,
      stagger: 0.2,
      ease: "back.out(1.7)"
  });
  
  // Animación para las tarjetas de autos
  gsap.from(".car-card", {
      scrollTrigger: {
          trigger: ".popular-cars",
          start: "top 80%",
      },
      duration: 0.8,
      opacity: 0,
      scale: 0.8,
      stagger: 0.15,
      ease: "elastic.out(1, 0.3)"
  });
  
  // Efecto de líneas que se dibujan (para un aspecto futurista)
  gsap.from(".feature-cards", {
      scrollTrigger: {
          trigger: ".features",
          start: "top 70%",
      },
      backgroundPosition: "200% 0",
      duration: 1.5,
      ease: "power3.out"
  });
});


document.getElementById('contact-form').addEventListener('submit', function(e) {
    e.preventDefault();
    const form = e.target;
    const data = new FormData(form);

    fetch(form.action, {
        method: form.method,
        body: data,
        headers: {
            'Accept': 'application/json'
        }
    }).then(response => {
        if (response.ok) {
            Swal.fire({
                icon: 'success',
                title: '¡Mensaje enviado!',
                text: 'Gracias por contactarnos. Te responderemos pronto.',
                confirmButtonColor: '#e10600'
            });
            form.reset();
        } else {
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: 'Hubo un problema al enviar el mensaje. Intenta nuevamente.',
                confirmButtonColor: '#e10600'
            });
        }
    });
});