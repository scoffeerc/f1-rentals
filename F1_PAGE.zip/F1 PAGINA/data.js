// Datos de los autos de F1
const cars = [
  {
    id: 2,
    name: "Red Bull RB16B",
    team: "Red Bull Racing",
    year: 2021,
    price: 24000,
    image: "img/cars/rb/rb16b.webp",
    description:
      "El Red Bull RB16B es un monoplaza de Fórmula 1 diseñado y construido por Red Bull Racing para competir en el Campeonato Mundial de Fórmula 1 de 2021.",
    maxSpeed: 365,
    acceleration: 2.5,
    history:
      "Con el RB16B, Max Verstappen consiguió su primer campeonato mundial de pilotos en 2021, en una de las temporadas más reñidas y emocionantes de la historia de la F1.",
    specs: {
      engine: "Honda RA621H",
      power: "Más de 950 CV",
      weight: "752 kg",
      transmission: "8 velocidades",
    },
  },
  {
    id: 3,
    name: "Ferrari SF21",
    team: "Ferrari",
    year: 2021,
    price: 22000,
    image: "img/cars/ferrari/ferrari.webp",
    description:
      "El Ferrari SF21 es un monoplaza de Fórmula 1 diseñado y construido por Scuderia Ferrari para competir en el Campeonato Mundial de Fórmula 1 de 2021.",
    maxSpeed: 360,
    acceleration: 2.7,
    history:
      "El SF21 representó un paso adelante para Ferrari después de una difícil temporada 2020. Con este coche, Charles Leclerc y Carlos Sainz lograron varios podios durante la temporada 2021.",
    specs: {
      engine: "Ferrari 065/6",
      power: "Más de 950 CV",
      weight: "752 kg",
      transmission: "8 velocidades",
    },
  },
  {
    id: 4,
    name: "McLaren MCL35M",
    team: "McLaren",
    year: 2021,
    price: 20000,
    image: "img/cars/mclaren/mclaren.webp",
    description:
      "El McLaren MCL35M es un monoplaza de Fórmula 1 diseñado y construido por McLaren para competir en el Campeonato Mundial de Fórmula 1 de 2021.",
    maxSpeed: 362,
    acceleration: 2.6,
    history:
      "Con el MCL35M, Daniel Ricciardo logró la victoria en el Gran Premio de Italia de 2021, dando a McLaren su primera victoria desde 2012. Lando Norris también consiguió varios podios con este coche.",
    specs: {
      engine: "Mercedes M12 E Performance",
      power: "Más de 950 CV",
      weight: "752 kg",
      transmission: "8 velocidades",
    },
  },
  {
    id: 5,
    name: "Alpine A521",
    team: "Alpine",
    year: 2021,
    price: 18000,
    image: "img/cars/alpine/alpine.jpg",
    description:
      "El Alpine A521 es un monoplaza de Fórmula 1 diseñado y construido por Alpine F1 Team para competir en el Campeonato Mundial de Fórmula 1 de 2021.",
    maxSpeed: 355,
    acceleration: 2.8,
    history:
      "Con el A521, Esteban Ocon logró su primera victoria en la Fórmula 1 en el Gran Premio de Hungría de 2021. Fernando Alonso también consiguió un podio en Qatar con este coche.",
    specs: {
      engine: "Renault E-Tech 20B",
      power: "Más de 900 CV",
      weight: "752 kg",
      transmission: "8 velocidades",
    },
  },
  {
    id: 6,
    name: "Aston Martin AMR23",
    team: "Aston Martin",
    year: 2023,
    price: 20000,
    image: "img/cars/aston/aston.jpg",
    description:
      "El Aston Martin AMR23 es un monoplaza de Fórmula 1 diseñado y construido por Aston Martin para competir en el Campeonato Mundial de Fórmula 1 de 2021.",
    maxSpeed: 350,
    acceleration: 2.9,
    history:
      "El AMR23 marcó una evolucion de Aston Martin en la Fórmula 1 como equipo de fábrica después de 60 años. Fernando Alonso logró multiples podios con este coche.",
    specs: {
      engine: "Mercedes M12 E Performance",
      power: "Más de 900 CV",
      weight: "752 kg",
      transmission: "8 velocidades",
    },
  },
  {
    id: 7,
    name: "Williams FW43B",
    team: "Williams",
    year: 2021,
    price: 15000,
    image: "img/cars/williams/williams.jpg",
    description:
      "El Williams FW43B es un monoplaza de Fórmula 1 diseñado y construido por Williams para competir en el Campeonato Mundial de Fórmula 1 de 2021.",
    maxSpeed: 345,
    acceleration: 3.0,
    history:
      "Con el FW43B, George Russell consiguió sus primeros puntos con Williams y un podio en el Gran Premio de Bélgica de 2021, en una carrera marcada por la lluvia.",
    specs: {
      engine: "Mercedes M12 E Performance",
      power: "Más de 900 CV",
      weight: "752 kg",
      transmission: "8 velocidades",
    },
  },
  {
    id: 8,
    name: "Lotus 97t",
    team: "Lotus",
    year: 1985,
    price: 30000,
    image: "img/cars/lotus/lotus.jpg",
    description:
      "El Lotus 97T es un monoplaza de Fórmula 1 diseñado y construido por Lotus para competir en el Campeonato Mundial de Fórmula 1 de 1985.",
    maxSpeed: 348,
    acceleration: 2.8,
    history:
      "Este icónico auto fue pilotado por Ayrton Senna, quien logró con él sus primeras victorias en la máxima categoría.",
    specs: {
      engine: "Honda RA621H",
      power: "Más de 900 CV",
      weight: "752 kg",
      transmission: "8 velocidades",
    },
  },
  {
    id: 9,
    name: "Ferrari F2004",
    team: "Ferrari",
    year: 2004,
    price: 30000,
    image: "img/cars/ferrari/f2004.jpg",
    description:
      "El Ferrari F2004 es uno de los monoplazas más exitosos en la historia de la Fórmula 1, diseñado por Ferrari para la temporada 2004.",
    maxSpeed: 350,
    acceleration: 2.8,
    history:
      "Con el F2004, Michael Schumacher ganó su séptimo y último campeonato mundial de pilotos. El coche ganó 15 de las 18 carreras de la temporada 2004, estableciendo numerosos récords.",
    specs: {
      engine: "Ferrari Tipo 053",
      power: "Más de 900 CV",
      weight: "605 kg",
      transmission: "7 velocidades",
    },
  },
  {
    id: 10,
    name: "McLaren MP4/4",
    team: "McLaren",
    year: 1988,
    price: 35000,
    image: "img/cars/mclaren/mclarenmp.webp",
    description:
      "El McLaren MP4/4 es considerado uno de los mejores monoplazas de Fórmula 1 de todos los tiempos, diseñado por McLaren para la temporada 1988.",
    maxSpeed: 330,
    acceleration: 3.2,
    history:
      "Con el MP4/4, Ayrton Senna ganó su primer campeonato mundial de pilotos. El coche ganó 15 de las 16 carreras de la temporada 1988, un récord de dominio que se mantuvo durante décadas.",
    specs: {
      engine: "Honda RA168E",
      power: "Más de 700 CV",
      weight: "540 kg",
      transmission: "6 velocidades",
    },
  },
  {
    id: 11,
    name: "Red Bull RB9",
    team: "Red Bull Racing",
    year: 2013,
    price: 28000,
    image: "img/cars/rb/rb9.jpg",
    description: "El Red Bull RB9 es un monoplaza de Fórmula 1 diseñado por Red Bull Racing para la temporada 2013.",
    maxSpeed: 340,
    acceleration: 2.7,
    history:
      "Con el RB9, Sebastian Vettel ganó su cuarto campeonato mundial consecutivo. El coche ganó 13 de las 19 carreras de la temporada 2013, incluyendo 9 victorias consecutivas de Vettel.",
    specs: {
      engine: "Renault RS27-2013",
      power: "Más de 750 CV",
      weight: "642 kg",
      transmission: "7 velocidades",
    },
  },
  {
    id: 12,
    name: "Mercedes W11",
    team: "Mercedes",
    year: 2020,
    price: 26000,
    image: "img/cars/mercedes/mercedes.jpg",
    description: "El Mercedes W11 es un monoplaza de Fórmula 1 diseñado por Mercedes para la temporada 2020.",
    maxSpeed: 365,
    acceleration: 2.6,
    history:
      "Con el W11, Lewis Hamilton igualó el récord de 7 campeonatos mundiales de Michael Schumacher. El coche ganó 13 de las 17 carreras de la temporada 2020, demostrando un dominio absoluto.",
    specs: {
      engine: "Mercedes M11 EQ Performance",
      power: "Más de 1000 CV",
      weight: "746 kg",
      transmission: "8 velocidades",
    },
  },
]

// Función para obtener todos los autos
function getAllCars() {
  return cars
}

// Función para obtener un auto por su ID
function getCarById(id) {
  return cars.find((car) => car.id === Number.parseInt(id))
}

// Función para obtener autos populares (los primeros 4)
function getPopularCars() {
  return cars.slice(0, 4)
}

// Función para obtener autos relacionados (excluyendo el auto actual)
function getRelatedCars(currentCarId) {
  return cars
    .filter((car) => car.id !== Number.parseInt(currentCarId))
    .sort(() => 0.5 - Math.random())
    .slice(0, 3)
}

// Función para filtrar autos
function filterCars(team = "", year = "", maxPrice = 50000) {
  return cars.filter((car) => {
    const teamMatch = team ? car.team === team : true
    const yearMatch = year ? car.year === Number.parseInt(year) : true
    const priceMatch = car.price <= maxPrice

    return teamMatch && yearMatch && priceMatch
  })
}

// Función para ordenar autos
function sortCars(cars, sortBy = "name-asc") {
  const sortedCars = [...cars]

  switch (sortBy) {
    case "name-asc":
      sortedCars.sort((a, b) => a.name.localeCompare(b.name))
      break
    case "name-desc":
      sortedCars.sort((a, b) => b.name.localeCompare(a.name))
      break
    case "price-asc":
      sortedCars.sort((a, b) => a.price - b.price)
      break
    case "price-desc":
      sortedCars.sort((a, b) => b.price - a.price)
      break
    case "year-asc":
      sortedCars.sort((a, b) => a.year - b.year)
      break
    case "year-desc":
      sortedCars.sort((a, b) => b.year - a.year)
      break
  }

  return sortedCars
}

// Función para obtener todas las escuderías únicas
function getAllTeams() {
  const teams = new Set()
  cars.forEach((car) => teams.add(car.team))
  return Array.from(teams)
}

// Función para obtener todos los años únicos
function getAllYears() {
  const years = new Set()
  cars.forEach((car) => years.add(car.year))
  return Array.from(years).sort((a, b) => b - a)
}
