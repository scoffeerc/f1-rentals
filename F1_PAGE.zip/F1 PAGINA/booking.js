document.addEventListener("DOMContentLoaded", () => {
  // ...existing code...

  // Mostrar selector de autos SIEMPRE arriba del formulario
  const bookingCarInfo = document.getElementById("booking-car-info");
  if (!bookingCarInfo) return;

  // Mostrar selector si no hay id en la URL
  function renderCarSelector(selectedId = "") {
    bookingCarInfo.innerHTML = `
      <div class="car-selector">
        <label for="car-select"><strong>Selecciona el auto que deseas alquilar:</strong></label>
        <select id="car-select" class="form-control">
          <option value="">-- Selecciona un auto --</option>
          ${cars.map(car => `<option value="${car.id}" ${car.id === selectedId ? "selected" : ""}>${car.name} (${car.team}, ${car.year}) - €${car.price}/día</option>`).join('')}
        </select>
      </div>
      <div id="selected-car-info"></div>
    `;
  }

  // Mostrar info del auto seleccionado
  function renderSelectedCarInfo(car) {
    const infoDiv = document.getElementById("selected-car-info");
    if (!infoDiv) return;
    if (!car) {
      infoDiv.innerHTML = "";
      document.getElementById("summary-car").textContent = "-";
      document.getElementById("summary-price").textContent = "-";
      updateBookingSummary();
      return;
    }
    infoDiv.innerHTML = `
      <div class="booking-car-image">
        <img src="${car.image}" alt="${car.name}">
      </div>
      <div class="booking-car-details">
        <h3>${car.name}</h3>
        <p class="team">${car.team}</p>
        <p class="year">${car.year}</p>
        <p class="price">€${car.price.toLocaleString()} / día</p>
        <p class="description">${car.description}</p>
      </div>
    `;
    document.getElementById("summary-car").textContent = car.name;
    document.getElementById("summary-price").textContent = `€${car.price.toLocaleString()}`;
    updateBookingSummary();
  }

  // Inicialización
  let selectedCar = null;
  const urlParams = new URLSearchParams(window.location.search);
  const carId = urlParams.get("id");

  renderCarSelector(carId || "");

  // Si hay id en la URL, selecciona ese auto
  if (carId) {
    selectedCar = getCarById(carId);
    renderSelectedCarInfo(selectedCar);
  }

  // Manejar cambio en el selector
  const carSelect = document.getElementById("car-select");
  if (carSelect) {
    carSelect.addEventListener("change", function () {
      const selectedId = this.value;
      selectedCar = getCarById(selectedId);
      renderSelectedCarInfo(selectedCar);
    });
  }

  // El resto del código (formulario, resumen, etc.) debe usar selectedCar
  // Por ejemplo, en updateBookingSummary y showConfirmation, usa selectedCar

  // Actualiza las funciones para usar selectedCar
  function updateBookingSummary() {
    if (!selectedCar) {
      document.getElementById("summary-days").textContent = "0";
      document.getElementById("summary-total").textContent = "€0";
      return;
    }
    const pickupDate = new Date(document.getElementById("pickup-date").value);
    const returnDate = new Date(document.getElementById("return-date").value);
    const diffTime = Math.abs(returnDate - pickupDate);
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    document.getElementById("summary-days").textContent = diffDays;
    const pricePerDay = selectedCar.price;
    const total = pricePerDay * diffDays;
    document.getElementById("summary-total").textContent = `€${total.toLocaleString()}`;
  }

  // showConfirmation también debe usar selectedCar
  function showConfirmation() {
    if (!selectedCar) return;
    // ...igual que antes, pero usando selectedCar...
  }

  // Manejar envío del formulario
  const bookingForm = document.getElementById("booking-form");
  if (bookingForm) {
    bookingForm.addEventListener("submit", (e) => {
      e.preventDefault();
      if (!selectedCar) {
        alert("Por favor selecciona un auto antes de reservar.");
        return;
      }
      showConfirmation();
    });
  }

  // Configurar fechas mínimas y listeners
  setupDates();
  const pickupDate = document.getElementById("pickup-date");
  const returnDate = document.getElementById("return-date");
  if (pickupDate && returnDate) {
    pickupDate.addEventListener("change", updateBookingSummary);
    returnDate.addEventListener("change", updateBookingSummary);
  }

  // Inicializar resumen
  updateBookingSummary();
});