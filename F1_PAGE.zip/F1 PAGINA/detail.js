document.addEventListener("DOMContentLoaded", () => {
  // Obtener ID del auto de la URL
  const urlParams = new URLSearchParams(window.location.search)
  const carId = urlParams.get("id")

  if (!carId) {
    window.location.href = "catalog.html"
    return
  }

  // Obtener datos del auto
  const car = getCarById(carId)

  if (!car) {
    window.location.href = "catalog.html"
    return
  }

  // Mostrar detalles del auto
  displayCarDetails(car)

  // Mostrar autos relacionados
  displayRelatedCars(carId)

  function displayCarDetails(car) {
    const carDetailContainer = document.getElementById("car-detail-container")
    if (!carDetailContainer) return

    const detailHTML = `
      <div class="container">
        <div class="car-detail-container">
          <div class="car-detail-image">
            <img src="${car.image}" alt="${car.name}">
          </div>
          <div class="car-detail-info">
            <h1>${car.name}</h1>
            <p class="team">${car.team}</p>
            <p class="year">${car.year}</p>
            <p class="price">€${car.price.toLocaleString()} / día</p>
            <p class="description">${car.description}</p>
            <div class="car-specs">
              <h3>Especificaciones</h3>
              <div class="specs-grid">
                <div class="spec-item"><p class="label">Velocidad Máxima</p><p class="value">${car.maxSpeed} km/h</p></div>
                <div class="spec-item"><p class="label">Aceleración 0-100 km/h</p><p class="value">${car.acceleration} s</p></div>
                <div class="spec-item"><p class="label">Motor</p><p class="value">${car.specs.engine}</p></div>
                <div class="spec-item"><p class="label">Potencia</p><p class="value">${car.specs.power}</p></div>
              </div>
            </div>
            <div class="car-history">
              <h3>Historia</h3>
              <p>${car.history}</p>
            </div>
            <a href="booking.html?id=${car.id}" class="btn btn-primary">Alquilar Ahora</a>
          </div>
        </div>
      </div>
    `

    carDetailContainer.innerHTML = detailHTML
    document.title = `${car.name} - F1 Rentals`
  }

  function displayRelatedCars(carId) {
    const relatedCarsContainer = document.getElementById("related-cars-container")
    if (!relatedCarsContainer) return

    const relatedCars = getRelatedCars(carId)

    relatedCars.forEach((car) => {
      const carCard = document.createElement("div")
      carCard.className = "car-card"
      carCard.innerHTML = `
        <div class="car-image"><img src="${car.image}" alt="${car.name}"></div>
        <div class="car-info">
          <h3>${car.name}</h3>
          <p class="team">${car.team}</p>
          <p class="year">${car.year}</p>
          <p class="price">€${car.price.toLocaleString()} / día</p>
          <a href="detail.html?id=${car.id}" class="btn btn-primary">Ver Detalles</a>
        </div>
      `
      relatedCarsContainer.appendChild(carCard)
    })
  }
})


