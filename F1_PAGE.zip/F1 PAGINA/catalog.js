document.addEventListener("DOMContentLoaded", () => {
  // Elementos del DOM
  const teamFilter = document.getElementById("team-filter")
  const yearFilter = document.getElementById("year-filter")
  const priceRange = document.getElementById("price-range")
  const priceValue = document.getElementById("price-value")
  const applyFiltersBtn = document.getElementById("apply-filters")
  const resetFiltersBtn = document.getElementById("reset-filters")
  const sortBy = document.getElementById("sort-by")
  const resultsCount = document.getElementById("results-count")
  const carCatalog = document.getElementById("car-catalog")

  // Datos de los autos (simulados)
  const carsData = [
  {
    id: 2,
    name: "Red Bull RB16B",
    team: "Red Bull Racing",
    year: 2021,
    price: 24000,
    image: "img/cars/rb/rb16b.webp",
    description:
      "El Red Bull RB16B es un monoplaza de Fórmula 1 diseñado y construido por Red Bull Racing para competir en el Campeonato Mundial de Fórmula 1 de 2021.",
    maxSpeed: 365,
    acceleration: 2.5,
    history:
      "Con el RB16B, Max Verstappen consiguió su primer campeonato mundial de pilotos en 2021, en una de las temporadas más reñidas y emocionantes de la historia de la F1.",
    specs: {
      engine: "Honda RA621H",
      power: "Más de 950 CV",
      weight: "752 kg",
      transmission: "8 velocidades",
    },
  },
  {
    id: 3,
    name: "Ferrari SF21",
    team: "Ferrari",
    year: 2021,
    price: 22000,
    image: "img/cars/ferrari/ferrari.webp",
    description:
      "El Ferrari SF21 es un monoplaza de Fórmula 1 diseñado y construido por Scuderia Ferrari para competir en el Campeonato Mundial de Fórmula 1 de 2021.",
    maxSpeed: 360,
    acceleration: 2.7,
    history:
      "El SF21 representó un paso adelante para Ferrari después de una difícil temporada 2020. Con este coche, Charles Leclerc y Carlos Sainz lograron varios podios durante la temporada 2021.",
    specs: {
      engine: "Ferrari 065/6",
      power: "Más de 950 CV",
      weight: "752 kg",
      transmission: "8 velocidades",
    },
  },
  {
    id: 4,
    name: "McLaren MCL35M",
    team: "McLaren",
    year: 2021,
    price: 20000,
    image: "img/cars/mclaren/mclaren.webp",
    description:
      "El McLaren MCL35M es un monoplaza de Fórmula 1 diseñado y construido por McLaren para competir en el Campeonato Mundial de Fórmula 1 de 2021.",
    maxSpeed: 362,
    acceleration: 2.6,
    history:
      "Con el MCL35M, Daniel Ricciardo logró la victoria en el Gran Premio de Italia de 2021, dando a McLaren su primera victoria desde 2012. Lando Norris también consiguió varios podios con este coche.",
    specs: {
      engine: "Mercedes M12 E Performance",
      power: "Más de 950 CV",
      weight: "752 kg",
      transmission: "8 velocidades",
    },
  },
  {
    id: 5,
    name: "Alpine A521",
    team: "Alpine",
    year: 2021,
    price: 18000,
    image: "img/cars/alpine/alpine.jpg",
    description:
      "El Alpine A521 es un monoplaza de Fórmula 1 diseñado y construido por Alpine F1 Team para competir en el Campeonato Mundial de Fórmula 1 de 2021.",
    maxSpeed: 355,
    acceleration: 2.8,
    history:
      "Con el A521, Esteban Ocon logró su primera victoria en la Fórmula 1 en el Gran Premio de Hungría de 2021. Fernando Alonso también consiguió un podio en Qatar con este coche.",
    specs: {
      engine: "Renault E-Tech 20B",
      power: "Más de 900 CV",
      weight: "752 kg",
      transmission: "8 velocidades",
    },
  },
  {
    id: 6,
    name: "Aston Martin AMR23",
    team: "Aston Martin",
    year: 2023,
    price: 20000,
    image: "img/cars/aston/aston.jpg",
    description:
      "El Aston Martin AMR23 es un monoplaza de Fórmula 1 diseñado y construido por Aston Martin para competir en el Campeonato Mundial de Fórmula 1 de 2021.",
    maxSpeed: 350,
    acceleration: 2.9,
    history:
      "El AMR23 marcó una evolucion de Aston Martin en la Fórmula 1 como equipo de fábrica después de 60 años. Fernando Alonso logró multiples podios con este coche.",
    specs: {
      engine: "Mercedes M12 E Performance",
      power: "Más de 900 CV",
      weight: "752 kg",
      transmission: "8 velocidades",
    },
  },
  {
    id: 7,
    name: "Williams FW43B",
    team: "Williams",
    year: 2021,
    price: 15000,
    image: "img/cars/williams/williams.jpg",
    description:
      "El Williams FW43B es un monoplaza de Fórmula 1 diseñado y construido por Williams para competir en el Campeonato Mundial de Fórmula 1 de 2021.",
    maxSpeed: 345,
    acceleration: 3.0,
    history:
      "Con el FW43B, George Russell consiguió sus primeros puntos con Williams y un podio en el Gran Premio de Bélgica de 2021, en una carrera marcada por la lluvia.",
    specs: {
      engine: "Mercedes M12 E Performance",
      power: "Más de 900 CV",
      weight: "752 kg",
      transmission: "8 velocidades",
    },
  },
  {
    id: 8,
    name: "Lotus 97t",
    team: "Lotus",
    year: 1985,
    price: 30000,
    image: "img/cars/lotus/lotus.jpg",
    description:
      "El Lotus 97T es un monoplaza de Fórmula 1 diseñado y construido por Lotus para competir en el Campeonato Mundial de Fórmula 1 de 1985.",
    maxSpeed: 348,
    acceleration: 2.8,
    history:
      "Este icónico auto fue pilotado por Ayrton Senna, quien logró con él sus primeras victorias en la máxima categoría.",
    specs: {
      engine: "Honda RA621H",
      power: "Más de 900 CV",
      weight: "752 kg",
      transmission: "8 velocidades",
    },
  },
  {
    id: 9,
    name: "Ferrari F2004",
    team: "Ferrari",
    year: 2004,
    price: 30000,
    image: "img/cars/ferrari/f2004.jpg",
    description:
      "El Ferrari F2004 es uno de los monoplazas más exitosos en la historia de la Fórmula 1, diseñado por Ferrari para la temporada 2004.",
    maxSpeed: 350,
    acceleration: 2.8,
    history:
      "Con el F2004, Michael Schumacher ganó su séptimo y último campeonato mundial de pilotos. El coche ganó 15 de las 18 carreras de la temporada 2004, estableciendo numerosos récords.",
    specs: {
      engine: "Ferrari Tipo 053",
      power: "Más de 900 CV",
      weight: "605 kg",
      transmission: "7 velocidades",
    },
  },
  {
    id: 10,
    name: "McLaren MP4/4",
    team: "McLaren",
    year: 1988,
    price: 35000,
    image: "img/cars/mclaren/mclarenmp.webp",
    description:
      "El McLaren MP4/4 es considerado uno de los mejores monoplazas de Fórmula 1 de todos los tiempos, diseñado por McLaren para la temporada 1988.",
    maxSpeed: 330,
    acceleration: 3.2,
    history:
      "Con el MP4/4, Ayrton Senna ganó su primer campeonato mundial de pilotos. El coche ganó 15 de las 16 carreras de la temporada 1988, un récord de dominio que se mantuvo durante décadas.",
    specs: {
      engine: "Honda RA168E",
      power: "Más de 700 CV",
      weight: "540 kg",
      transmission: "6 velocidades",
    },
  },
  {
    id: 11,
    name: "Red Bull RB9",
    team: "Red Bull Racing",
    year: 2013,
    price: 28000,
    image: "img/cars/rb/rb9.jpg",
    description: "El Red Bull RB9 es un monoplaza de Fórmula 1 diseñado por Red Bull Racing para la temporada 2013.",
    maxSpeed: 340,
    acceleration: 2.7,
    history:
      "Con el RB9, Sebastian Vettel ganó su cuarto campeonato mundial consecutivo. El coche ganó 13 de las 19 carreras de la temporada 2013, incluyendo 9 victorias consecutivas de Vettel.",
    specs: {
      engine: "Renault RS27-2013",
      power: "Más de 750 CV",
      weight: "642 kg",
      transmission: "7 velocidades",
    },
  },
  {
    id: 12,
    name: "Mercedes W11",
    team: "Mercedes",
    year: 2020,
    price: 26000,
    image: "img/cars/mercedes/mercedes.jpg",
    description: "El Mercedes W11 es un monoplaza de Fórmula 1 diseñado por Mercedes para la temporada 2020.",
    maxSpeed: 365,
    acceleration: 2.6,
    history:
      "Con el W11, Lewis Hamilton igualó el récord de 7 campeonatos mundiales de Michael Schumacher. El coche ganó 13 de las 17 carreras de la temporada 2020, demostrando un dominio absoluto.",
    specs: {
      engine: "Mercedes M11 EQ Performance",
      power: "Más de 1000 CV",
      weight: "746 kg",
      transmission: "8 velocidades",
    },
  },
]

  // Función para obtener todas las escuderías
  function getAllTeams() {
    return [...new Set(carsData.map((car) => car.team))]
  }

  // Función para obtener todos los años
  function getAllYears() {
    return [...new Set(carsData.map((car) => car.year))]
  }

  // Función para filtrar autos
  function filterCars(team, year, maxPrice) {
    let filtered = carsData

    if (team) {
      filtered = filtered.filter((car) => car.team === team)
    }

    if (year) {
      filtered = filtered.filter((car) => car.year === Number.parseInt(year))
    }

    filtered = filtered.filter((car) => car.price <= maxPrice)

    return filtered
  }

  // Función para ordenar autos
  function sortCars(cars, sortOption) {
    switch (sortOption) {
      case "name-asc":
        return cars.sort((a, b) => a.name.localeCompare(b.name))
      case "name-desc":
        return cars.sort((a, b) => b.name.localeCompare(a.name))
      case "price-asc":
        return cars.sort((a, b) => a.price - b.price)
      case "price-desc":
        return cars.sort((a, b) => b.price - a.price)
      default:
        return cars
    }
  }

  // Función para obtener todas las escuderías
  function getAllTeams() {
    return [...new Set(carsData.map((car) => car.team))].sort()
  }

  // Función para obtener todos los años
  function getAllYears() {
    return [...new Set(carsData.map((car) => car.year))].sort((a, b) => b - a)
  }

  // Función para filtrar autos
  function filterCars(team, year, maxPrice) {
    let filtered = carsData

    if (team) {
      filtered = filtered.filter((car) => car.team === team)
    }

    if (year) {
      filtered = filtered.filter((car) => car.year === Number.parseInt(year))
    }

    filtered = filtered.filter((car) => car.price <= maxPrice)

    return filtered
  }

  // Función para ordenar autos
  function sortCars(cars, sortOption) {
    switch (sortOption) {
      case "name-asc":
        return cars.sort((a, b) => a.name.localeCompare(b.name))
      case "name-desc":
        return cars.sort((a, b) => b.name.localeCompare(a.name))
      case "price-asc":
        return cars.sort((a, b) => a.price - b.price)
      case "price-desc":
        return cars.sort((a, b) => b.price - a.price)
      case "year-asc":
        return cars.sort((a, b) => a.year - b.year)
      case "year-desc":
        return cars.sort((a, b) => b.year - a.year)
      default:
        return cars
    }
  }

  // Cargar opciones de filtros
  loadFilterOptions()

  // Mostrar valor del rango de precio
  if (priceRange) {
    priceRange.addEventListener("input", () => {
      priceValue.textContent = `€${Number.parseInt(priceRange.value).toLocaleString()}`
    })
  }

  // Aplicar filtros
  if (applyFiltersBtn) {
    applyFiltersBtn.addEventListener("click", () => {
      filterAndDisplayCars()
    })
  }

  // Resetear filtros
  if (resetFiltersBtn) {
    resetFiltersBtn.addEventListener("click", () => {
      teamFilter.value = ""
      yearFilter.value = ""
      priceRange.value = 50000
      priceValue.textContent = `€50,000`
      sortBy.value = "name-asc"
      filterAndDisplayCars()
    })
  }

  // Ordenar autos
  if (sortBy) {
    sortBy.addEventListener("change", () => {
      filterAndDisplayCars()
    })
  }

  // Cargar todos los autos al inicio
  filterAndDisplayCars()

  // Función para cargar opciones de filtros
  function loadFilterOptions() {
    // Cargar escuderías
    const teams = getAllTeams()
    teams.forEach((team) => {
      const option = document.createElement("option")
      option.value = team
      option.textContent = team
      teamFilter.appendChild(option)
    })

    // Cargar años
    const years = getAllYears()
    years.forEach((year) => {
      const option = document.createElement("option")
      option.value = year
      option.textContent = year
      yearFilter.appendChild(option)
    })
  }

  // Función para filtrar y mostrar autos
  function filterAndDisplayCars() {
    const team = teamFilter.value
    const year = yearFilter.value
    const maxPrice = Number.parseInt(priceRange.value)
    const sortOption = sortBy.value

    // Filtrar autos
    let filteredCars = filterCars(team, year, maxPrice)

    // Ordenar autos
    filteredCars = sortCars(filteredCars, sortOption)

    // Actualizar contador de resultados
    resultsCount.textContent = `(${filteredCars.length})`

    // Mostrar autos
    displayCars(filteredCars)
  }

  // Función para mostrar autos en el catálogo
  function displayCars(cars) {
    carCatalog.innerHTML = ""

    if (cars.length === 0) {
      carCatalog.innerHTML =
        '<p class="no-results">No se encontraron autos que coincidan con los filtros seleccionados.</p>'
      return
    }

    cars.forEach((car, index) => {
      const carCard = document.createElement("div")
      carCard.className = "car-card"
      carCard.style.animationDelay = `${index * 0.1}s`

      carCard.innerHTML = `
        <div class="car-image">
          <img src="${car.image}" alt="${car.name}" loading="lazy">
        </div>
        <div class="car-info">
          <h3>${car.name}</h3>
          <p class="team">${car.team}</p>
          <p class="year">${car.year}</p>
          <p class="price">€${car.price.toLocaleString()} / día</p>
          <a href="detail.html?id=${car.id}" class="btn btn-primary">Ver Detalles</a>
        </div>
      `

      carCatalog.appendChild(carCard)
    })
  }
})